#!/bin/bash
NUM_CORES=8

for s in archaea bacteria eukaryotes; do
cd $s
for i in `seq 50`;do
cd $i

../../bin/RAxML-Light-1.0.5/raxmlLight-PTHREADS -T $NUM_CORES -s sample.phy -q RAxML_modelResult.naive.part -m PROTGAMMAWAGF -t RAxML_parsimonyTree.START -n naive_inf
../../bin/RAxML-Light-1.0.5/raxmlLight-PTHREADS -T $NUM_CORES -s sample.phy -q RAxML_modelResult.exhaustive.part -m PROTGAMMAWAGF -t RAxML_parsimonyTree.START -n exhaustive_inf

cd ..
done
cd ..
done
