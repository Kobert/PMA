#!/bin/bash
NUM_CORES=48

for s in archaea bacteria eukaryotes; do
cd $s
for i in `seq 50`;do
cd $i

../../bin/modelAssignment -T $NUM_CORES -q sample.part -s sample.phy -n naive -l NAIVE
../../bin/modelAssignment -T $NUM_CORES -q sample.part -s sample.phy -n exhaustive -l EXHAUSTIVE

cd ..
done
cd ..
done
