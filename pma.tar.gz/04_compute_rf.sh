#!/bin/bash
NUM_CORES=2

for s in archaea bacteria eukaryotes; do
cd $s
for i in `seq 50`;do
cd $i

cat RAxML_result.exhaustive_inf > results.tre
cat RAxML_result.naive_inf >> results.tre

../../bin/standard-RAxML/raxmlHPC-PTHREADS-SSE3 -T $NUM_CORES -f r -z results.tre -m PROTGAMMAWAG -n rf 

cd ..
done
cd ..
done
