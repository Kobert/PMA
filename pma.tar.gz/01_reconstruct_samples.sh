#!/bin/bash

for s in archaea bacteria eukaryotes; do
cd $s
for i in `seq 50`;do
cd $i

java -jar ../../bin/phymod.jar extract -n sample -T `tr '\n' ',' < species.txt` -P `tr '\n' ',' < partitions.txt` ../$s.part ../$s.phy

cd ..
done
cd ..
done
