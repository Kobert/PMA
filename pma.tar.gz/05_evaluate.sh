#!/bin/bash
# detailed RF-distances go here
rfFile=`pwd`"/rf_dists.txt"
# detailed PMA differences go here
diffFile=`pwd`"/model_diffs.txt"
# summarized output goes here
summaryFile=`pwd`"/summary.txt"

#number of partitions
NUM=3
#number of data samples
nrRuns=50

#compute mean of a vector
function mean {
        R --silent --slave 2> /dev/null << EOF
        d <- scan()
        $1

        write(mean(d),file="mean")
EOF

        res=`cat mean`
        rm mean
}


#counts the differing partition models
#@param 1 first name
#@param 2 second name
function countModelDiffs {
	t=0
	for j in `seq $NUM`; do
		a=`sed -n "$j"p RAxML_modelResult.$1`
		b=`sed -n "$j"p RAxML_modelResult.$2`
		if [ $a != $b ]; then
			# echo file $i m1: $a m2: $b
			t=$(($t+1))
		fi
	done
}

#computes the likelihood difference
#@param 1 first name
#@param 2 second name
function LHdiff {
		countModelDiffs $1 $2
		if [ $t -gt 0 ]; then
			e1=`grep "Likelihood   : .*" RAxML_info.$1"_inf" | sed 's/Likelihood   :\s*//'`
			o1=`grep "Likelihood   : .*" RAxML_info.$2"_inf" | sed 's/Likelihood   :\s*//'`
			diff="$1: $e1\t$i: $o1"
			echo -e "$1: $e1\t$i: $o1"
		fi
}


#@param 1 first name
#@param 2 second name
function summarizeModelDiffs {
	count=0
	n=0

	for f in `seq $nrRuns`; do
		cd $f
		countModelDiffs $1 $2

		echo "$f: $t" >> $diffFile

		if [ $t -gt 0 ]; then
			count=$((count+1))
		fi
		n=$((n+1))

		cd ..
	done

	res="different PMA in $count cases ($(($count * 100 / $n))%)"
	echo -e $res >> $summaryFile
}

#@param 1 first name
#@param 2 second name
function summarizeRFDists {
	count=0
	sum=0
	res=""

	for f in `seq $nrRuns`; do
		cd $f
		countModelDiffs $1 $2

		if [ $t -gt 0 ]; then
			tmp=`cat RAxML_RF-Distances.rf | cut -d " " -f4`
			echo "$f: $tmp" >> $rfFile
			res="$res $tmp"
			count=$((count+1))
		fi

		cd ..
	done

	mean "$res"
	echo "average RF distance of $count cases is $res" >> $summaryFile
}


#check if better model assignment enhance tree sarch results
#if not this function prints a summary
#@param 1 first name
#@param 2 second name
function treeEnhancement {
	for f in `seq $nrRuns`; do
		if [ -d $f ]; then
			cd $f
			NUM=`wc -l < sample.part`
				countModelDiffs $1 $2
				if [ $t -gt 0 ]; then
					e1=`grep "Likelihood   : .*" RAxML_info.$1 | sed 's/Likelihood   :\s*//'`				
					e2=`grep "Likelihood   : .*" RAxML_info.$1"_inf" | sed 's/Likelihood   :\s*//'`
					if [ $2 = "naive" ]; then
						o1=`grep "Naive, opt+JBL:  " RAxML_info.$1 | cut -d " " -f4`
					else
						o1=`grep "Likelihood   : .*" RAxML_info.$2 | sed 's/Likelihood   :\s*//'`
					fi
					o2=`grep "Likelihood   : .*" RAxML_info.$2"_inf" | sed 's/Likelihood   :\s*//'`

					init=`echo "$e1-($o1)" | bc | awk '{printf "%f", $0}'`
					final=`echo "$e2-($o2)" | bc | awk '{printf "%f", $0}'`

					if [ `echo $init | cut -d '.' -f1` -lt 0 ] && [ `echo $final | cut -d '.' -f1` -gt 0 ]; then
						printf "%2d: %d  %4.0f  %4.0f (%s)\n" $f $t $init $final $i
					fi
				fi
	
			cd ..
		fi
	done
}

outer="exhaustive"
inner="naive"

for s in archaea bacteria eukaryotes; do
cd $s
	echo $s >> $diffFile
	echo $s >> $summaryFile
	echo $s >> $rfFile

	summarizeModelDiffs $outer $inner
	summarizeRFDists $outer $inner	

	echo "" >> $diffFile
	echo "" >> $summaryFile
	echo "" >> $rfFile
cd ..
done
